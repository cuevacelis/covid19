self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "72b993956382a9ec534b9d88d957865c",
    "url": "/covid19/index.html"
  },
  {
    "revision": "3e32c230dfe304c24d97",
    "url": "/covid19/static/css/2.3adc8b4e.chunk.css"
  },
  {
    "revision": "c75f6c93c21d48bdc12c",
    "url": "/covid19/static/js/index.0ada65d1.production.min.js"
  },
  {
    "revision": "3e32c230dfe304c24d97",
    "url": "/covid19/static/js/index.2.3ea59f56.production.chunk.min.js"
  },
  {
    "revision": "5356fa2f66e46e6c05e4cbe319ac7f1d",
    "url": "/covid19/static/js/index.2.3ea59f56.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "1b97f747794a59715f9b",
    "url": "/covid19/static/js/index.main.f496f932.production.chunk.min.js"
  },
  {
    "revision": "94958d243703d4af2bc6f59fda91902b",
    "url": "/covid19/static/media/logo.94958d24.svg"
  }
]);
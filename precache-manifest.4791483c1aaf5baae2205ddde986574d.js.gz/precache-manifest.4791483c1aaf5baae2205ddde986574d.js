self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2906ca98018c163b0e58c3f7391276de",
    "url": "/covid19/index.html"
  },
  {
    "revision": "e4366379b086e7440020",
    "url": "/covid19/static/css/2.3adc8b4e.chunk.css"
  },
  {
    "revision": "d04bd1870d1b4a2ddd7e",
    "url": "/covid19/static/css/main.5ecd60fb.chunk.css"
  },
  {
    "revision": "c75f6c93c21d48bdc12c",
    "url": "/covid19/static/js/index.0ada65d1.production.min.js"
  },
  {
    "revision": "e4366379b086e7440020",
    "url": "/covid19/static/js/index.2.52be7e9a.production.chunk.min.js"
  },
  {
    "revision": "5356fa2f66e46e6c05e4cbe319ac7f1d",
    "url": "/covid19/static/js/index.2.52be7e9a.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "d04bd1870d1b4a2ddd7e",
    "url": "/covid19/static/js/index.main.7714bca4.production.chunk.min.js"
  },
  {
    "revision": "94958d243703d4af2bc6f59fda91902b",
    "url": "/covid19/static/media/logo.94958d24.svg"
  }
]);
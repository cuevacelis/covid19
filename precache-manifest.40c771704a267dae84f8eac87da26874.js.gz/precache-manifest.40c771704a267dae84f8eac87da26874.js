self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ade848829a89b26e697b67140924e0f1",
    "url": "/covid19/index.html"
  },
  {
    "revision": "eb1a64b9061508c66423",
    "url": "/covid19/static/css/2.3adc8b4e.chunk.css"
  },
  {
    "revision": "92e03c25106cff9ac38f",
    "url": "/covid19/static/css/main.5ecd60fb.chunk.css"
  },
  {
    "revision": "c75f6c93c21d48bdc12c",
    "url": "/covid19/static/js/index.0ada65d1.production.min.js"
  },
  {
    "revision": "eb1a64b9061508c66423",
    "url": "/covid19/static/js/index.2.af62004d.production.chunk.min.js"
  },
  {
    "revision": "5356fa2f66e46e6c05e4cbe319ac7f1d",
    "url": "/covid19/static/js/index.2.af62004d.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "92e03c25106cff9ac38f",
    "url": "/covid19/static/js/index.main.0ab333fc.production.chunk.min.js"
  },
  {
    "revision": "94958d243703d4af2bc6f59fda91902b",
    "url": "/covid19/static/media/logo.94958d24.svg"
  }
]);
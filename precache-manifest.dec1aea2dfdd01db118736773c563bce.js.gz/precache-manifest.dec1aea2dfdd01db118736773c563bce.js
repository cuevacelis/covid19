self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "31fae6eb0961d79dc6e3191bac29adaf",
    "url": "/covid19/index.html"
  },
  {
    "revision": "e4366379b086e7440020",
    "url": "/covid19/static/css/2.3adc8b4e.chunk.css"
  },
  {
    "revision": "226ec80390fe8a2e5bb5",
    "url": "/covid19/static/css/main.5ecd60fb.chunk.css"
  },
  {
    "revision": "c75f6c93c21d48bdc12c",
    "url": "/covid19/static/js/index.0ada65d1.production.min.js"
  },
  {
    "revision": "e4366379b086e7440020",
    "url": "/covid19/static/js/index.2.52be7e9a.production.chunk.min.js"
  },
  {
    "revision": "5356fa2f66e46e6c05e4cbe319ac7f1d",
    "url": "/covid19/static/js/index.2.52be7e9a.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "226ec80390fe8a2e5bb5",
    "url": "/covid19/static/js/index.main.0dec1400.production.chunk.min.js"
  },
  {
    "revision": "94958d243703d4af2bc6f59fda91902b",
    "url": "/covid19/static/media/logo.94958d24.svg"
  }
]);
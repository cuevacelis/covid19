self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9b504ba99139007643b09718f7f2d308",
    "url": "/covid19/index.html"
  },
  {
    "revision": "4c8167ae1de5fa99881a",
    "url": "/covid19/static/css/2.54f8f250.chunk.css"
  },
  {
    "revision": "f4be5e15c5485002223d",
    "url": "/covid19/static/css/main.9a83aaa5.chunk.css"
  },
  {
    "revision": "4c8167ae1de5fa99881a",
    "url": "/covid19/static/js/index.2.3ac0e784.production.chunk.min.js"
  },
  {
    "revision": "45c3b0e6a77e536ad25f6ffa575bb86a",
    "url": "/covid19/static/js/index.2.3ac0e784.production.chunk.min.js.LICENSE.txt"
  },
  {
    "revision": "94b0e18d7e349d5238f5",
    "url": "/covid19/static/js/index.f4e09d02.production.min.js"
  },
  {
    "revision": "f4be5e15c5485002223d",
    "url": "/covid19/static/js/index.main.4f6c4602.production.chunk.min.js"
  },
  {
    "revision": "94958d243703d4af2bc6f59fda91902b",
    "url": "/covid19/static/media/logo.94958d24.svg"
  }
]);